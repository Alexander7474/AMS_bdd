# AMS_bdd
Projet AMS java et modélisation de base de données Alexandre LANTERNIER et Florent CAGNARD

# Setup 

Impossible de se connecter sur etd avec ssh et pedago, on a donc utilisez notre propre server postegrsql.     
Nous avons utilisez swing pour créer l'interface graphique

# Info

-> Les permissions utilisateur n'on pas pus être implémentées     
-> Certain menu ne se rafraîchisse pas lors de modification, il faut donc cliquer à nouveau sur le menu pour les voires apparaître     
-> Le script creation_table.sql contient des données pour tester le logiciel en plus de la structure de la base de données       
-> 

# Status

![Static Badge](https://img.shields.io/badge/Working%20on%20pedago-X-red?style=flat-square)